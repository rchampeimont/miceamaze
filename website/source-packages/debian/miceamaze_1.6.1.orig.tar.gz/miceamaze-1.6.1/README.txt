========================
HOW TO COMPILE MICEAMAZE
========================

On Linux you need:
- SDL installed, with headers (package usually called somthing like libsdl-dev)
- OpenGL headers (GL/gl.h and GL/glu.h, might come as somthing like libmesa-dev)
- GCC C and C++ compilers

How to do it:
make
./miceamaze

