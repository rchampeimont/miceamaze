======================
HOW TO BUILD MICEAMAZE
======================

You need:
- GCC C++ compiler and GNU Make
- OpenGL
- SDL
- SOIL
- QuesoGLC
- DejaVu font installed
- rsvg


Without installing:
make
./miceamaze

With installation (requires root privileges):
make
sudo make install
miceamaze

