// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.


#include "RenderFlatText.h"
#include "Program.h"

// State:
// 0 = normal
// 1 = mouse over
// 2 = pressed
void Button::render(int state) {
	if (!shown) return;

	float borderY = h/15;
	float borderX = borderY/4*3;

	glBegin(GL_QUADS);

	if (state != 2) {
		glColor3f(color.r*1, color.g*1, color.b*1);
	} else {
		glColor3f(color.r*0.4, color.g*0.4, color.b*0.4);
	}
	glVertex2f(x, y);
	glVertex2f(x, y+h);
	glVertex2f(x+w, y+h);
	glVertex2f(x+w, y);

	if (state == 1) {
		glColor3f(color.r*0.7, color.g*0.7, color.b*0.7);
	} else {
		glColor3f(color.r*0.6, color.g*0.6, color.b*0.6);
	}
	glVertex2f(x+borderX, y+borderY);
	glVertex2f(x+borderX, y+h-borderY);
	glVertex2f(x+w-borderX, y+h-borderY);
	glVertex2f(x+w-borderX, y+borderY);

	glEnd();

	if (state != 2) {
		glColor3f(color.r*0.4, color.g*0.4, color.b*0.4);
	} else {
		glColor3f(color.r*1, color.g*1, color.b*1);
	}
	glBegin(GL_POLYGON);
	glVertex2f(x, y);
	glVertex2f(x+borderX, y+borderY);
	glVertex2f(x+w-borderX, y+borderY);
	glVertex2f(x+w, y);
	glEnd();

	glBegin(GL_POLYGON);
	glVertex2f(x+w-borderX, y+borderY);
	glVertex2f(x+w-borderX, y+h-borderY);
	glVertex2f(x+w, y+h);
	glVertex2f(x+w, y);
	glEnd();

	glTranslatef(x+w/2, y+h/2, 0);
	if (state == 2) {
		glTranslatef(borderX/2, -borderY/2, 0);
	}
	glScalef(0.1*textSizeFactor, 0.1*textSizeFactor, 1);
	glTranslatef(0, -0.5, 0);
	glColor3f(1, 1, 1);
	RenderFlatText::render(text, 0);
}


