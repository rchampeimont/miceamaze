// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef HOUSE_H_
#define HOUSE_H_

class Maze;
class Game;

class House {
public:
	static unsigned int texture;
	static unsigned int textureFirst;
	static void loadTextures();
	int i, j, player;
	void render(Maze*, Game*);
	House(int i0, int j0, int p) {
		i = i0;
		j = j0;
		player = p;
	}
};


#endif /* HOUSE_H_ */
