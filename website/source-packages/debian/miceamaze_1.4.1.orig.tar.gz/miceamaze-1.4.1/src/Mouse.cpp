// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#include "Mouse.h"
#include "Program.h"

unsigned int Mouse::mouseTexture = 0;

Mouse::Mouse(Maze *m, int x0, int y0, int dir): Animal(m, x0, y0, dir) {
	color.r = (rand() % 1000) / 1000.0;
	color.g = color.r;
	color.b = color.r;
	magic = false;
}

void Mouse::makeMagic() {
	magic = true;
}

void Mouse::loadTexture() {
	mouseTexture = Program::getInstance()->loadTexture(Program::getInstance()->dataPath + "/images/mouse.png");
}

bool Mouse::reachedHouse(Game *game, int player) {
	game->scores[player]++;
	if (magic) {
		game->magicHappens(player);
	}
	return true;
}

int Mouse::isKilled() {
	for (unsigned int k=0; k<maze->snakes.size(); k++) {
		Snake *snake = &maze->snakes[k];
		int snake_dxu = snake->direction == 0 ? 1 : (snake->direction == 2 ? -1 : 0);
		int snake_dyu = snake->direction == 1 ? 1 : (snake->direction == 3 ? -1 : 0);
		float snakeMouthX = snake->x + snake_dxu*0.5;
		float snakeMouthY = snake->y + snake_dyu*0.5;
		float dist = Functions::fabs(snakeMouthX - x) + Functions::fabs(snakeMouthY - y);
		if (dist < 0.2) {
			// The snake eats the mouse.
			// A snake becomes sick after eating too much mice.
			snake->life -= 0.05;
			if (snake->life < 0) {
				snake->life = 0;
			}
			return 1;
		}
	}
	return 0;
}

void Mouse::render() {
	glLoadMatrixf(maze->modelMatrix);
	float x1 = maze->x0 + x*maze->cellWidth;
	float y1 = maze->y0 + y*maze->cellHeight;
	glTranslatef(x1, y1, 0);
	glRotatef(angle - 90, 0, 0, 1);
	glScalef(maze->cellWidth*0.5, maze->cellHeight*0.5, 0);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, mouseTexture);
	glBegin(GL_QUADS);
	if (magic) {
		adjustColor(Color(1, 0.7, 0)).gl();
		glTexCoord2f(0, 0); glVertex2f(-1, -1);
		glTexCoord2f(0, 1); glVertex2f(-1, 1);
		glTexCoord2f(1, 1); glVertex2f(1, 1);
		glTexCoord2f(1, 0); glVertex2f(1, -1);
	} else {
		adjustColor(color).gl();
		glTexCoord2f(0, 0); glVertex2f(-1, -1);
		glTexCoord2f(0, 1); glVertex2f(-1, 1);
		glTexCoord2f(1, 1); glVertex2f(1, 1);
		glTexCoord2f(1, 0); glVertex2f(1, -1);
	}
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
}

Color Mouse::adjustColor(Color c) {
	if (inHouse > 0) {
		c.a = 1 - inHouse;
	} else {
		c.r = c.r+(1-c.r)*(1-dieAnim);
		c.g = c.g*dieAnim;
		c.b = c.b*dieAnim;
		c.a = dieAnim;
	}
	return c;
}



