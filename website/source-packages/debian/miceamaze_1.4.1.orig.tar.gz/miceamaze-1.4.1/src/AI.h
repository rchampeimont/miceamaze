// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef AI_H_
#define AI_H_

#include "Functions.h"

#include "AIVertex.h"
#include "AIVertexHeap.h"
#include "MouseWithDistance.h"

using namespace std;

class AI {
public:
	Maze *maze;
	int player;
	vector<AIVertex> graph;
	int homeI, homeJ;

	// Dijkstra's algo stuff
	vector<int> pathToHome;
	vector<bool> dijkstraVisited;
	AIVertexHeap dijkstraQ;
	vector<MouseWithDistance> sortedMice;
	AI(int, Maze*);
	~AI();
	void init();
	void play();
	void updateGraph();
	void computeDistances();

	// Edge weights for the following things
	static int forwardCost() {
		return 1;
	}
	static int arrowCost() {
		return 10;
	}
	static int infinity() {
		return 1000000;
	}

	int getDistance(int vertexIndex) {
		return graph[vertexIndex].distance;
	}

	int vertexIndexFromCoords(int i, int j, int dir) {
		Functions::verify(i >= 0 && i < maze->height, "vertexIndexFromCoords: invalid i:", i);
		Functions::verify(j >= 0 && j < maze->width, "vertexIndexFromCoords: invalid j:", j);
		Functions::verify(dir >= 0 && dir < 4, "vertexIndexFromCoords: invalid dir", dir);
		return i*4*maze->width + 4*j + dir;
	}

	AIVertex *vertexFromCoords(int i, int j, int dir) {
		return &graph[vertexIndexFromCoords(i, j, dir)];
	}

	int vertexI(int vertexIndex) {
		return vertexIndex / (4*maze->width);
	}

	int vertexJ(int vertexIndex) {
		return (vertexIndex % (4*maze->width))/4;
	}

	int vertexDir(int vertexIndex) {
		return vertexIndex % 4;
	}

	void vertexCoords(int vertexIndex, int *i, int *j, int *dir) {
		Functions::verify(vertexIndex >= 0 && vertexIndex < (int) graph.size(), "vertexCoords: invalid vertex index", vertexIndex);
		if (i != NULL) *i = vertexI(vertexIndex);
		if (j != NULL) *j = vertexJ(vertexIndex);
		if (dir != NULL) *dir = vertexDir(vertexIndex);
	}

	string vertexString(int vertexIndex) {
		int i, j, dir;
		vertexCoords(vertexIndex, &i, &j, &dir);
		return string("(") + Functions::toString(i) + "," + Functions::toString(j) + "," + Functions::toString(dir) + ")";
	}


	int nextVertex(int vertexIndex, int direction);
	int edgeWeight(int u, int v);
	void getPreviousVertices(int vertexIndex, int previousVertices[4]);
};


#endif /* AI_H_ */
