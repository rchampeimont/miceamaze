// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef AIVERTEX_H_
#define AIVERTEX_H_


// In our graph, a vertex is a (cell, direction) couple.
// The vertices are number first by row, then by colum, then by direction.
class AIVertex {
public:
	// cost (in number of arrows to place) to go to directions
	// by convention, same dir as current vertex = next cell,
	// otherwise: same cell but rotate
	int right, up, down, left;
	int index;
	int distance;
	AIVertex(int r, int u, int l, int d, int i) {
		right = r;
		up = u;
		left = l;
		down = d;
		index = i;
		distance = 0;

	}
	void zeroAllDirs() {
		right = up = left = down = 0;
	}
	int getWeight(int dir) {
		switch (dir) {
			case 0:
				return right;
			case 1:
				return up;
			case 2:
				return left;
			case 3:
				return down;
			default:
				Functions::fatalError("getWeight: invalid dir");
				return 0; // never reached
		}
	}
	int *weight(int dir) {
			switch (dir) {
				case 0:
					return &right;
				case 1:
					return &up;
				case 2:
					return &left;
				case 3:
					return &down;
				default:
					Functions::fatalError("getWeight: invalid dir");
					return NULL; // never reached
			}
		}
};



#endif /* AIVERTEX_H_ */
