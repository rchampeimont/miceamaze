// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef MOUSEWITHDISTANCE_H_
#define MOUSEWITHDISTANCE_H_

class Mouse;

class MouseWithDistance {
	Mouse *mouse;
public:
	int distance;

	Mouse *getMouse() {
		return mouse;
	}

	MouseWithDistance(Mouse *m, int d) {
		mouse = m;
		distance = d;
	}

    bool operator < (const MouseWithDistance& otherMouse) const
    {
        return (distance < otherMouse.distance);
    }
};


#endif /* MOUSEWITHDISTANCE_H_ */
