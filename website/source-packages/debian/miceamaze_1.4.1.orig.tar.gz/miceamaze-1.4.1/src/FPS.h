// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef FPS_H_
#define FPS_H_

#include "Program.h"

class FPS {
public:
	int fps;
	int framesSinceLastSecond;
	Uint32 lastSecond;
	bool limitFPS;

	FPS();
	~FPS();
	void render();
	void renderInGame();
	void update() {
		framesSinceLastSecond++;
		Uint32 t = SDL_GetTicks();
		if (t - lastSecond > 1000) {
			fps = framesSinceLastSecond;
			lastSecond = t;
			framesSinceLastSecond = 0;
		}
	}

	void decideLimitFPS();

	// "Standard" wait between two frames in menu-like things
	// that don't need dynamic delay adjustment.
	// This is useful to prevent coil noise when FPS are very high
	// (as menus are rendered very fast - like 1000 FPS),
	// and it also saves power since we don't need thousands of FPS in a menu.
	void waitStandard() {
		SDL_Delay(5);
	}
};


#endif /* FPS_H_ */
