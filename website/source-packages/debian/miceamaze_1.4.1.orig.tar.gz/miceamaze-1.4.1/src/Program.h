// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef MAINCLASS_H_
#define MAINCLASS_H_

#include "Functions.h"

// Our headers
#include "IntXY.h"
#include "FloatXY.h"
#include "Button.h"
#include "Maze.h"
#include "AI.h"
#include "Game.h"
#include "MenuSelectMaze.h"
#include "MenuMain.h"
#include "MenuAbout.h"
#include "MenuPlayers.h"
#include "MenuOptions.h"
#include "Color.h"
#include "Cursor.h"
#include "Config.h"
#include "Images.h"
#include "FPS.h"
#include "RenderFlatText.h"
#include "Button.h"

class FPS;


using namespace std;

// This class is a singleton.
class Program {
	static Program *instance;
public:
	int argc;
	char **argv;
	bool fullscreen;
	int screenWidth, screenHeight, screenBPP, screenOffsetX, screenOffsetY;
	float screenRatio;
	SDL_Cursor *emptyCursor;
	SDL_Surface *screen;
	vector<Color> playerColors;
	Config config;
	IntXY nativeResolution;
	int initVideoCounter;
	int scene;
	string mazeToLoad;
	IntXY resizedWindow;
	FPS *fps;
	string dataPath;

	Program(int argc, char *argv[]);
	void run();
	void titleScreen();
	~Program();
	SDL_Cursor *init_system_cursor(const char *[]);
	void initVideo();
	void autoDetectFps();
	void toggleFullscreen();
	void reinitVideo();
	void loadAllTextures();
	int loadTexture(string);
	int loadTexture(string, IntXY *);

	void generalEventHandler(SDL_Event *event);

	// Get instance of MainClass
	static Program *getInstance() {
		return instance;
	}

	void glCoordsFromWindowCoords(int x, int y, float *xgl, float *ygl) {
		if (xgl != NULL) *xgl = (float) (x-screenOffsetX) / screenWidth * 2 - 1;
		if (ygl != NULL) *ygl = - ((float) (y-screenOffsetY) / screenHeight * 2 - 1);
	}

};



#endif
