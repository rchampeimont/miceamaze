// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef MENUOPTIONS_H_
#define MENUOPTIONS_H_


#include "Program.h"


using namespace std;

class MenuOptions {
	int initVideoCounter;
	GLuint fixedObjectsDisplayList;
	bool hasDisplayList;
	vector<Button> buttons;

public:
	Cursor cursor;

	MenuOptions();
	~MenuOptions();
	void run();
	void prepareRender();
	void selectOption(int);
};



#endif /* MENUOPTIONS_H_ */
