// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef MOUSE_H_
#define MOUSE_H_

#include "Color.h"
#include "Animal.h"

class Maze;

// Class for mouse (the animal, not the input device)
class Mouse: public Animal {
	 bool magic;
public:
	static unsigned int mouseTexture;
	static void loadTexture();
	Mouse(Maze *, int, int, int);
	bool reachedHouse(Game*, int);
	void render();
	int isKilled();
	void makeMagic();
	Color adjustColor(Color);
};

#endif /* MOUSE_H_ */
