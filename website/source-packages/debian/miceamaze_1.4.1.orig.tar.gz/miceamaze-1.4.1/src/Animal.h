// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef ANIMAL_H_
#define ANIMAL_H_

#include "Color.h"

class Maze;
class Game;

class Animal {
public:
	static int loadTexture(const char*);
	float x;
	float y;
	int curI, curJ;
	float angle; // angle in degrees (0 is the right, positive is anti-clockwise)
	int direction; // 0 = right, 1 = up, 2 = left, 3 = down
	float speed;
	int rotating; // 0 = not rotating, 1 = rotating left, -1 = rotating right
	Maze *maze;
	Color color;
	bool obeyed;
	bool dying;
	float dieAnim;
	float inHouse;
	float life;

	virtual void render() {}
	Animal(Maze*, int, int, int);
	int walk(Game*);
	void getFutureCell(int*, int*);

	virtual bool reachedHouse(Game *, int);
	virtual int isKilled() {
		return 0;
	}
	virtual ~Animal() {}
};

#endif /* ANIMAL_H_ */
