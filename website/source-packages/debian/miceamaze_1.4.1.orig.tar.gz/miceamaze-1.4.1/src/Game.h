// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef GAME_H_
#define GAME_H_

#include <iostream>
#include "SDL.h"

#include "Program.h"
#include "Maze.h"
#include "Cursor.h"

using namespace std;

class Game {
	int initVideoCounter;
	vector<Button> buttons;
public:
	bool running;
	bool ended;
	Uint32 lastSecond;
	Uint32 lastGameTick;
	int framesSinceLastSecond;
	int ticksSinceLastSecond;
	int frameDelay;
	Maze maze;
	vector<Cursor*> cursors;
	vector<int> scores;
	int players;
	int time;
	int timeLimit;
	int eagleOwner;
	bool pause;
	int specialMode;
	int specialModeStart;
	string message;
	int messageTime;
	vector<AI> AIs;
	Cursor cursor;

	Game();
	~Game();
	void run();
	void togglePause();
	void magicHappens(int);
	void showMessage(string);
	int getLeader();
	void prepareRender();
};

#endif /* GAME_H_ */
