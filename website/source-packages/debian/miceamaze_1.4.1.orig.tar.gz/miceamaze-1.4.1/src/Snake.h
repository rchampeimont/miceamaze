// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef SNAKE_H_
#define SNAKE_H_

#include "Animal.h"
#include "Color.h"


class Maze;

class Snake: public Animal {
public:
	static unsigned int snakeTexture;
	static void loadTexture();
	Snake(Maze *, int, int, int);
	bool reachedHouse(Game *, int);
	void render();
	Color adjustColor(Color);
};


#endif /* SNAKE_H_ */
