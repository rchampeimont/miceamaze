// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef MENUPLAYERS_H_
#define MENUPLAYERS_H_

#include "Program.h"


using namespace std;

class MenuPlayers {
	int initVideoCounter;
	GLuint fixedObjectsDisplayList;
	bool hasDisplayList;
	vector<Button> buttons;

	static int firstControlButton() {
		return 1;
	}

	void selectControls(int player, int control);
public:
	// 0 = Mouse, 1 = keyboard, 2 = AI, 3 = None
	static int playerControls[4];
	Cursor cursor;

	MenuPlayers();
	~MenuPlayers();
	void run();
	void prepareRender();
};



#endif /* MENUPLAYERS_H_ */
