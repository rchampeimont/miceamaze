// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef MAZE_H_
#define MAZE_H_

#include <iostream>
#include <vector>

#include "Wall.h"
#include "Mouse.h"
#include "Snake.h"
#include "Arrow.h"
#include "House.h"
#include "Spawner.h"
#include "IntXY.h"


using namespace std;

class Game;

class Maze {
	bool hasDisplayList;
public:
	int size, width, height;
	vector<Wall> vWalls, hWalls;
	vector<vector<int> > hWallsAsMatrix;
	vector<vector<int> > vWallsAsMatrix;
	vector<Mouse> mice;
	vector<Snake> snakes;
	vector<Arrow> arrows;
	vector<House> houses;
	vector<Spawner> spawners;
	float x0;
	float y0;
	float cellWidth;
	float cellHeight;
	GLfloat modelMatrix[16];
	GLuint fixedObjectsDisplayList;
	string name, description;

	Maze();
	~Maze();
	void render(Game *);
	void runTick(Game *);
	int x2i(float x) {
		if (x >= 0)
			return (int) x;
		else
			return ((int) x) - 1;
	}
	IntXY nextCell(int,int,int);
	bool crossesWall(int,int,int,int);
	int addArrow(int,int,int,int);
	int maxArrowsByPlayer;
	void save(string);
	void load(string);
	void prepare();
	void prepareRender(Game *game);
	void randomizeHouses();
};

#endif /* MAZE_H_ */
