// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef INTXY_H_
#define INTXY_H_

class IntXY {
public:
	int x, y;
	IntXY() {
		x = y = 0;
	}
	IntXY(int x0, int y0) {
		x = x0;
		y = y0;
	}
};

#endif
