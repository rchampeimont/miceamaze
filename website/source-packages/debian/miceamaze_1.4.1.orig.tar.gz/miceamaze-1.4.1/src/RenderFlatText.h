// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef RENDERFLATTEXT_H_
#define RENDERFLATTEXT_H_

#include "Program.h"

class RenderFlatText {
	static vector<unsigned int> widths;
public:
	static int charHeight;
	static void loadTextures();
	static vector<unsigned int> textures;
	static void render(string s) {
		render(s, -1);
	}
	static void render(string s, int align);
};


#endif
