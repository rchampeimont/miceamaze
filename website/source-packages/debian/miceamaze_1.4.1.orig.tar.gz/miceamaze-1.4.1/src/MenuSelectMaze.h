// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef MENUSELECTMAZE_H_
#define MENUSELECTMAZE_H_

#include <iostream>
#include "SDL.h"

#include "Program.h"
#include "Maze.h"
#include "Cursor.h"

using namespace std;

class MenuSelectMaze {
	int initVideoCounter;
	void updatePagesButtons();
	vector<Button> buttons;
public:
	Cursor cursor;
	vector<Maze*> mazes;
	vector<string> mazePaths;
	vector<string> availableMazes;
	static int page;

	MenuSelectMaze();
	~MenuSelectMaze();
	void run();
	void addMaze(string);
	void loadMazes();
	void loadNewMazes();
	void prepareMazesRender();
	void prepareRender();
	void translateForMazeRender(int, int);
	void searchMazes();
};


#endif /* MENU_H_ */
