// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef COLOR_H_
#define COLOR_H_

#include "Functions.h"

class Color {
public:
	float r, g, b, a;
	Color(float rc, float gc, float bc) {
		r = rc;
		g = gc;
		b = bc;
		a = 1;
	}
	Color(float rc, float gc, float bc, float ac) {
		r = rc;
		g = gc;
		b = bc;
		a = ac;
	}
	Color() {
		r = g = b = 0;
		a = 1;
	}
	void black() {
		r = g = b = 0;
		a = 1;
	}
	void white() {
		r = g = b = 1;
		a = 1;
	}
	void gl() {
		glColor4f(r, g, b, a);
	}
	void gl4() {
		glColor4f(r, g, b, a);
	}
	void gl3() {
		glColor3f(r, g, b);
	}
};

#endif /* COLOR_H_ */
