// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#include "Images.h"
#include "Program.h"

vector<unsigned int> Images::textures;
vector<int> Images::widths;
vector<int> Images::heights;

void Images::loadTextures() {
	loadImage("eagle.png");
	loadImage("eagle2.png");
	loadImage("license.png");
}

void Images::loadImage(string filename) {
	IntXY wh;
	unsigned int texture = Program::getInstance()->loadTexture((Program::getInstance()->dataPath + "/images/" + filename).c_str(), &wh);
	textures.push_back(texture);
	widths.push_back(wh.x);
	heights.push_back(wh.y);
}

void Images::clearTextures() {
	textures.clear();
	widths.clear();
	heights.clear();
}

void Images::renderImage(int imageIndex) {
	if ((unsigned) imageIndex >= textures.size() || imageIndex < 0)
		return;
	glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, textures[imageIndex]);
	glBegin(GL_QUADS);
	FloatXY r = scaleRatio(imageIndex);
	glTexCoord2f(0, 0); glVertex3f(-r.x, -r.y*Program::getInstance()->screenRatio, 0);
	glTexCoord2f(0, 1); glVertex3f(-r.x, r.y*Program::getInstance()->screenRatio, 0);
	glTexCoord2f(1, 1); glVertex3f(r.x, r.y*Program::getInstance()->screenRatio, 0);
	glTexCoord2f(1, 0); glVertex3f(r.x, -r.y*Program::getInstance()->screenRatio, 0);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
}

FloatXY Images::scaleRatio(int imageIndex) {
	FloatXY res;
	int w = widths[imageIndex];
	int h = heights[imageIndex];
	if (w > h) {
		res.x = 1;
		res.y = (float) h / (float) w;
	} else {
		res.y = 1;
		res.x = (float) w / (float) h;
	}
	return res;
}
