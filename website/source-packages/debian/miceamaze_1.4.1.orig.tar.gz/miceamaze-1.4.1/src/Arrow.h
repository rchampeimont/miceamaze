// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef ARROW_H_
#define ARROW_H_

#include "Functions.h"

class Maze;

class Arrow {
public:
	int i, j;
	int player;
	int direction;
	void render(Maze*);
	Arrow() {
		i = j = player = direction = 0;
	}
	Arrow(int i0, int j0, int p, int d) {
		i = i0;
		j = j0;
		player = p;
		direction = d;
	}
	// to which cell the arrow points
	void pointsTo(int *i1, int *j1) {
		if (j1 != NULL)
			*j1 = (direction == 0 ? j+1 : (direction == 2 ? j-1 : j));
		if (i1 != NULL)
			*i1 = (direction == 1 ? i+1 : (direction == 3 ? i-1 : i));
	}
};


#endif /* ARROW_H_ */
