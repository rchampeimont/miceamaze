// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef MENUMAIN_H_
#define MENUMAIN_H_

#include "Functions.h"

#include "Program.h"

using namespace std;

class MenuMain {
	int initVideoCounter;
	GLuint fixedObjectsDisplayList;
	bool hasDisplayList;
public:
	Cursor cursor;

	MenuMain();
	~MenuMain();
	void run();
	void prepareRender();
};


#endif /* MENUPLAYERS_H_ */
