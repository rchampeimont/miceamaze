// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#include "Snake.h"
#include "Program.h"

unsigned int Snake::snakeTexture = 0;

Snake::Snake(Maze *m, int x0, int y0, int dir): Animal(m, x0, y0, dir) {
	color.r = 1;
	color.g = 0.5;
	color.b = 1;
	speed = 0.015;
}

void Snake::loadTexture() {
	snakeTexture = Program::getInstance()->loadTexture(Program::getInstance()->dataPath + "/images/snake.png");
}

bool Snake::reachedHouse(Game *game, int player) {
	if (game->eagleOwner == player) {
		// the eagle kills the snake
		dying = true;
		return false;
	} else {
		// snake reaches house
		game->scores[player] -= 10;
		return true;
	}
}


void Snake::render() {
	glLoadMatrixf(maze->modelMatrix);
	float x1 = maze->x0 + x*maze->cellWidth;
	float y1 = maze->y0 + y*maze->cellHeight;
	glTranslatef(x1, y1, -0.0005);
	glRotatef(angle - 90, 0, 0, 1);
	glScalef(maze->cellWidth*0.6, maze->cellHeight*0.6, 0);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, snakeTexture);
	glBegin(GL_QUADS);
	adjustColor(color).gl();
	glTexCoord2f(0, 0); glVertex2f(-1, -1);
	glTexCoord2f(0, 1); glVertex2f(-1, 1);
	glTexCoord2f(1, 1); glVertex2f(1, 1);
	glTexCoord2f(1, 0); glVertex2f(1, -1);
	glEnd();
	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
}


Color Snake::adjustColor(Color c) {
	c.r = c.r*life;
	c.g = c.g+(1-c.g)*(1-life);
	if (inHouse > 0) {
		c.a = 1 - inHouse;
	} else {
		c.r = c.r*dieAnim;
		c.g = c.g+(1-c.g)*(1-dieAnim);
		c.a = dieAnim;
	}
	return c;
}


