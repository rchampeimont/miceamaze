// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef AIVERTEXHEAP_H_
#define AIVERTEXHEAP_H_

#include "Functions.h"
#include "AIVertex.h"

class AIVertexHeap {
	vector<AIVertex*> A;
	vector<int> vertexIndexToHeapIndex;
	int maxHeapSize; // allocate heap size (max currentSize possible)
	int currentSize; // current size = # of vertices currently in the heap
	void heapify(int k);
	bool exists(int k) {
		return k >= 0 && k < currentSize;
	}
	void updateVertexIndexToHeapIndex(int heapIndex) {
		Functions::verify(exists(heapIndex), "AIVertexHeap updateVertexIndexToHeapIndex error");
		vertexIndexToHeapIndex[A[heapIndex]->index] = heapIndex;
	}
	void swap(int a, int b) {
		Functions::verify(exists(a) && exists(b), "AIVertexHeap swap error");
		AIVertex *tmp;
		tmp = A[a];
		A[a] = A[b];
		A[b] = tmp;
		updateVertexIndexToHeapIndex(a);
		updateVertexIndexToHeapIndex(b);
	}
public:
	void reset(vector<AIVertex>*);
	AIVertex *extractMin();
	bool empty() {
		return currentSize == 0;
	}
	void decreaseKey(AIVertex*);
	AIVertexHeap(int);
};


#endif /* AIVERTEXHEAP_H_ */
