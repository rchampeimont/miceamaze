// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#include "Cursor.h"
#include "Program.h"

Cursor::Cursor(int p) {
	x = y = 0;
	player = p;
	hasDisplayList = false;
}

Cursor::~Cursor() {
	if (hasDisplayList)
		glDeleteLists(displayList, 1);
}

void Cursor::prepareRender() {
	displayList = glGenLists(1);
	hasDisplayList = true;
	glNewList(displayList, GL_COMPILE);

	float scaleFactor = 0.14;
	glColor3f(1, 1, 1);
	glBegin(GL_TRIANGLE_STRIP);
	glVertex2f(0, -1*scaleFactor);
	glVertex2f(0, 0);
	glVertex2f(0.2*scaleFactor, -0.5*scaleFactor);
	glVertex2f(0.7*scaleFactor, -0.7*scaleFactor);
	glEnd();

	glTranslatef(0.005, -0.015, 0);
	scaleFactor = 0.1;
	if (player >= 0) {
		Program::getInstance()->playerColors[player].gl();
	} else {
		glColor3f(1, 0.5, 0);
	}
	glBegin(GL_TRIANGLE_STRIP);
	glVertex2f(0, -1*scaleFactor);
	glVertex2f(0, 0);
	glVertex2f(0.2*scaleFactor, -0.5*scaleFactor);
	glVertex2f(0.7*scaleFactor, -0.7*scaleFactor);
	glEnd();

	glEndList();
}

void Cursor::render() {
	glLoadIdentity();
	glTranslatef(x, y, 0);
	if (!glIsList(displayList)) {
		Functions::error("no list");
	}
	glCallList(displayList);
}

// Return -1 if cursor is not on a cell
int Cursor::getCellJ(Maze *maze) {
	int j = (x - maze->x0) / maze->cellWidth;
	if (j < 0 || j >= maze->width) {
		return -1;
	} else {
		return j;
	}
}

// Return -1 if cursor is not on a cell
int Cursor::getCellI(Maze *maze) {
	int i = (y - maze->y0) / maze->cellHeight;
	if (i < 0 || i >= maze->height) {
		return -1;
	} else {
		return i;
	}
}

void Cursor::setFromWindowXY(int x1, int y1) {
	Program::getInstance()->glCoordsFromWindowCoords(x1, y1, &x, &y);
}
