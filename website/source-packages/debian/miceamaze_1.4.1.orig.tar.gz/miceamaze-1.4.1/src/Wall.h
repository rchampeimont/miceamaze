// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef WALL_H_
#define WALL_H_


class Wall {
public:
	int i;
	int j;
	Wall(int i0, int j0) {
		i = i0;
		j = j0;
	}
};

#endif /* WALL_H_ */
