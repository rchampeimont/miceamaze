// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef FLOATXY_H_
#define FLOATXY_H_

class FloatXY {
public:
	float x, y;
	FloatXY() {
		x = y = 0;
	}
	FloatXY(float x0, float y0) {
		x = x0;
		y = y0;
	}
};

#endif /* FLOATXY_H_ */
