// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef SPAWNER_H_
#define SPAWNER_H_

#include "Functions.h"

class Maze;
class Game;

class Spawner {
	Maze *maze;
	int getNextDir() {
		if (direction == -1) {
			return rand() % 4;
		} else {
			return direction;
		}
	}

public:
	static unsigned int texture;
	static void loadTexture();
	static int directionFromLetterCode(char);
	static bool isSpawnerLetterCode(char);

	int i, j;
	int counter;

	// -1 for random or 0 to 3 for direction
	int direction;

	void render();
	Spawner(Maze *, int, int, int);
	void tick(Game *);
	char getLetterCode();

};



#endif /* SPAWNER_H_ */
