// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef CONFIG_H_
#define CONFIG_H_

#include <iostream>

using namespace std;

class Config {
public:
	string path;

	// -1 = powersave, 1 = max FPS, 0 = automatic (max on AC power / save on battery)
	int fpsBehaviour;

	bool showFPS;

	Config();
	void load();
	void save();
	string configFilePath() {
		return path + "/config.txt";
	}
};


#endif /* CONFIG_H_ */
