// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef MENUABOUT_H_
#define MENUABOUT_H_

#include "Functions.h"

#include "Program.h"

using namespace std;

class MenuAbout {
	int initVideoCounter;
	GLuint fixedObjectsDisplayList;
	bool hasDisplayList;
public:
	Cursor cursor;

	MenuAbout();
	~MenuAbout();
	void run();
	void prepareRender();
};




#endif /* MENUABOUT_H_ */
