// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#include "Program.h"

using namespace std;

void end() {
	if (Program::getInstance() != NULL) {
		delete Program::getInstance();
	}
}

int main(int argc, char *argv[]) {
	Program *mainInstance = new Program(argc, argv);
	atexit(end);
	mainInstance->run();
	return 0;
}
