// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#include "FPS.h"
#include "RenderFlatText.h"

FPS::FPS() {
	fps = -1;
	framesSinceLastSecond = 0;
	lastSecond = SDL_GetTicks();
	limitFPS = false;
}

FPS::~FPS() {

}

void FPS::decideLimitFPS() {
	// Config explicitly decides between powersave or max FPS?
	if (Program::getInstance()->config.fpsBehaviour == 1) {
		limitFPS = false;
		return;
	} else if (Program::getInstance()->config.fpsBehaviour == -1) {
		limitFPS = true;
		return;
	}

	// Max FPS unless we have a reason to set otherwise
	limitFPS = false;
	// Detect if we are on battery
#ifdef _WIN32
	SYSTEM_POWER_STATUS powerStatus;
	if (GetSystemPowerStatus(&powerStatus)) {
		if (powerStatus.ACLineStatus == 0) {
			// We are on battery, so limit FPS to save energy
			limitFPS = true;
		}
	}
#endif
}

void FPS::render() {
	if (!Program::getInstance()->config.showFPS) return;
	glLoadIdentity();
	glTranslatef(0.72, -0.99, 0);
	glScalef(0.05, 0.05, 1);
	if (fps < 20 && fps >= 0)
		glColor3f(1, 0, 0);
	else
		glColor3f(0.8, 0.7, 0.4);
	if (fps >= 0) {
		string s = "FPS: " + Functions::toString(fps) + " (lim)";
		RenderFlatText::render(s);
	} else {
		RenderFlatText::render("FPS: ");
	}
}


void FPS::renderInGame() {
	if (!Program::getInstance()->config.showFPS) return;
	glLoadIdentity();
	glTranslatef(0.72, -0.99, 0);
	glScalef(0.05, 0.05, 1);
	if (fps < 20 && fps >= 0)
		glColor3f(1, 0, 0);
	else
		glColor3f(0.8, 0.7, 0.4);
	if (fps >= 0) {
		string s = "FPS: " + Functions::toString(fps);
		if (limitFPS) {
			s += " (lim)";
		}
		RenderFlatText::render(s);
	} else {
		RenderFlatText::render("FPS: ");
	}
}
