// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.


#ifndef IMAGES_H_
#define IMAGES_H_

#include "Program.h"

class Images {
	static vector<unsigned int> textures;
	static vector<int> widths;
	static vector<int> heights;
	static void loadImage(string);
public:
	static void clearTextures();
	static void loadTextures();
	static unsigned int getTexture(int imageIndex) {
		if (textures.size() == 0)
			loadTextures();
		return (textures[imageIndex]);
	}
	static void renderImage(int);
	static FloatXY scaleRatio(int);
};


#endif /* IMAGES_H_ */
