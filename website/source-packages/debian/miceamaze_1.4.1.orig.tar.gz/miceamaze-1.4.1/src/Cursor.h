// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef CURSOR_H_
#define CURSOR_H_

#include "Functions.h"

class Maze;
class Game;

class Cursor {
	int player;
	GLuint displayList;
	bool hasDisplayList;
public:
	// cords on real screen (not on maze)
	float x, y;

	void prepareRender();
	void render();
	Cursor(int);
	~Cursor();
	int getPlayer() {
		return player;
	}
	int getCellI(Maze*);
	int getCellJ(Maze*);
	void setFromWindowXY(int x1, int y1);
	void setFromMouse() {
		int x1, y1;
		SDL_GetMouseState(&x1, &y1);
		setFromWindowXY(x1, y1);
	}
};


#endif /* CURSOR_H_ */
