// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#include "RenderFlatText.h"

vector<unsigned int> RenderFlatText::textures;
vector<unsigned int> RenderFlatText::widths;
int RenderFlatText::charHeight = 0;

void RenderFlatText::loadTextures() {
	char s[100];
	for (int i=32; i<256; i++) {
		sprintf(s, "%s/images/chars/%03d.png", Program::getInstance()->dataPath.c_str(), i);
		IntXY wh;
		textures.push_back(Program::getInstance()->loadTexture(s, &wh));
		charHeight = wh.y; // we assume char height is the same for all
		widths.push_back(wh.x);
	}
}

// align: -1 = left (original position = left of the text)
// align:  0 = center (original position = middle of the text)
// align:  1 = right (original position = right of the text)
void RenderFlatText::render(string s, int align) {

	glDisable(GL_DEPTH_TEST);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glEnable(GL_TEXTURE_2D);

	float delta = 0;
	if (align == 1 || align == 0) {
		for (unsigned k=0; k<s.length(); k++) {
			int c = (int) s[k];
			if (c < 0) c += 256;
			c -= 32; // 32 = first printable char in latin1
			if (c < 0) continue; // c is non-printable
			float wf = (float) widths[c]/charHeight*0.75;
			delta += wf+0.05;
		}
	}
	if (align == 1) {
		glTranslatef(-delta, 0, 0);
	} else if (align == 0) {
		glTranslatef(-delta/2, 0, 0);
	}

	for (unsigned k=0; k<s.length(); k++) {
		int c = (int) s[k];
		if (c < 0) c += 256;
		c -= 32; // 32 = first printable char in latin1
		if (c < 0) continue; // c is non-printable
		glBindTexture(GL_TEXTURE_2D, textures[c]);
		glBegin(GL_QUADS);
		float wf = (float) widths[c]/charHeight*0.75;
		glTexCoord2f(0, 0); glVertex3f(0, 0, 0);
		glTexCoord2f(0, 1); glVertex3f(0, 1, 0);
		glTexCoord2f(1, 1); glVertex3f(wf, 1, 0);
		glTexCoord2f(1, 0); glVertex3f(wf, 0, 0);
		glEnd();
		glTranslatef(wf+0.05, 0, 0);
	}

	glDisable(GL_TEXTURE_2D);
	glDisable(GL_BLEND);
}
