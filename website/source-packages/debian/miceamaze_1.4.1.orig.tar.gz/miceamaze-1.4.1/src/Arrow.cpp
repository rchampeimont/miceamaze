// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.


#include "Arrow.h"
#include "Program.h"

void Arrow::render(Maze *maze) {
	glLoadMatrixf(maze->modelMatrix);
	float x1 = maze->x0 + (j+0.5)*maze->cellWidth;
	float y1 = maze->y0 + (i+0.5)*maze->cellHeight;
	glTranslatef(x1, y1, 0);
	glScalef(maze->cellWidth*0.3, maze->cellHeight*0.3, 0);
	glRotatef(direction*90, 0, 0, 1);
	Program::getInstance()->playerColors[player].gl();
	glBegin(GL_TRIANGLES);
	glVertex2f(-1, 1);
	glVertex2f(1, 0);
	glVertex2f(-1, -1);
	glEnd();
}

