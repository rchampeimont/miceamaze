// Copyright (c) 2012, RAPHAEL CHAMPEIMONT
// All rights reserved.

#ifndef BUTTON_H_
#define BUTTON_H_

class Button {
public:
	float x, y, w, h, textSizeFactor;
	string text;
	Color color;
	bool shown;

	Button(float x0, float y0, float w0, float h0, string text0, float textSizeFactor0) : color(1,1,1) {
		x = x0;
		y = y0;
		w = w0;
		h = h0;
		text = text0;
		textSizeFactor = textSizeFactor0;
		shown = true;
	}

	Button(float x0, float y0, float w0, float h0, string text0) : color(1,1,1) {
		x = x0;
		y = y0;
		w = w0;
		h = h0;
		text = text0;
		textSizeFactor = 1.0f;
		shown = true;
	}

	bool over(float curx, float cury) {
		if (!shown) return false;
		return curx >= x && curx <= x+w && cury >= y && cury <= y+h;
	}

	void render(int state);

	void select(bool state) {
		if (state) {
			color.r = 1;
			color.g = 0.5;
			color.b = 0;
		} else {
			color.white();
		}
	}
};


#endif /* BUTTON_H_ */
